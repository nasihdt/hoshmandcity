package Model;

import java.util.ArrayList;

public class Data {
    public static Shahrdar shahrdar;
    public static Assistants assistants;
    public static Bazras bazras;
    public static Employee employee;
    public static Herasat herasat;
    public static Univercity univercity;
    public static Hospital hospital;
    public static Airport airport;
    public static Library library;
    public static LanguageInstitute languageInstitute;

    public static ArrayList<Employee> emplist = new ArrayList<>();
    public static ArrayList<Assistants> assislist= new ArrayList<>();
    public static ArrayList<Bazras> bazraslist = new ArrayList<>();
    public static ArrayList<Herasat> herasatlist = new ArrayList<>();
    public static ArrayList<Univercity> unilist = new ArrayList<>();
    public static ArrayList<Hospital> hoslist = new ArrayList<>();
    public static ArrayList<Airport> airportslist = new ArrayList<>();
    public static ArrayList<Library> liblist = new ArrayList<>();
    public static ArrayList<LanguageInstitute> languagelist = new ArrayList<>();
}
