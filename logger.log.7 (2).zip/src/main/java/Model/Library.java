package Model;

public class Library extends Department{
    public Library(String namePlace,String phonenumber,String addressPlace,String namebos,String numberofemp){
        super(namePlace,phonenumber,addressPlace,namebos,numberofemp);

    }
}
