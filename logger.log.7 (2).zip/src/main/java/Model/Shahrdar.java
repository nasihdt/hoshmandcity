package Model;


public class Shahrdar extends Person {

       public Shahrdar(String name, String lastname, String personelynumber, String hire_date, String salary, String sabeghe){
           super(name,lastname,personelynumber,hire_date,salary,sabeghe);

       }


    public Shahrdar() {
        super();
    }

}
