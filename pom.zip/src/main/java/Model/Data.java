package Model;

import java.util.ArrayList;

public class Data {
    public static Shahrdar shahrdar;
    public static Assistants assistants;
    public static Bazras bazras;
    public static Employee employee;
    public static Herasat herasat;
    public static ArrayList<Employee> emplist = new ArrayList<>();
    public static ArrayList<Assistants> assislist= new ArrayList<>();
    public static ArrayList<Bazras> bazraslist = new ArrayList<>();
    public static ArrayList<Herasat> herasatlist = new ArrayList<>();

}
