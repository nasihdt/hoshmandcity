package Model;

public class Department {

}
