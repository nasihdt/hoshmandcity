package Model;

public class LanguageInstitute extends Department{
    public LanguageInstitute(String namePlace,String phonenumber,String addressPlace,String namebos,String numberofemp){
        super(namePlace,phonenumber,addressPlace,namebos,numberofemp);

    }
}
