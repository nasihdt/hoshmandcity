package com.example.hoshmandcity;

import Model.*;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

public class Main extends Application {


    static FileHandler handler;

    static {
        try {
            handler = new FileHandler("logger.log",true);
        } catch (IOException e) {
            Logger logger = Logger.getLogger("com.javacodesgeeks.snippets.core");
            logger.addHandler(handler);
            logger.warning("warning message");
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) throws Exception{
        File.writeshahrdar("C:\\Users\\Asus\\IdeaProjects\\hoshmandcity\\src\\main\\java\\Model\\1.Shahrdar");
        File.writeassistant("C:\\Users\\Asus\\IdeaProjects\\hoshmandcity\\src\\main\\java\\Model\\2.Assistant",Data.assislist);
        File.writeBaz("C:\\Users\\Asus\\IdeaProjects\\hoshmandcity\\src\\main\\java\\Model\\3.Bazrass",Data.bazraslist);
        File.writeEmp("C:\\Users\\Asus\\IdeaProjects\\hoshmandcity\\src\\main\\java\\Model\\4.Employee",Data.emplist);
        File.writeHeras("C:\\Users\\Asus\\IdeaProjects\\hoshmandcity\\src\\main\\java\\Model\\5.Heras",Data.herasatlist);
        File.writeuniver("C:\\Users\\Asus\\IdeaProjects\\hoshmandcity\\src\\main\\java\\Model\\1.Univercity",Data.unilist);
        File.writeair("C:\\Users\\Asus\\IdeaProjects\\hoshmandcity\\src\\main\\java\\Model\\2.Airport",Data.airportslist);
        File.writelib("C:\\Users\\Asus\\IdeaProjects\\hoshmandcity\\src\\main\\java\\Model\\3.Library",Data.liblist);
        File.writehost("C:\\Users\\Asus\\IdeaProjects\\hoshmandcity\\src\\main\\java\\Model\\4.Hospital",Data.hoslist);
        File.writestitute("C:\\Users\\Asus\\IdeaProjects\\hoshmandcity\\src\\main\\java\\Model\\5.Language",Data.languagelist);
        FirstPage();
    }

    public static void FirstPage(){
        try {
           Stage Firstpage = new Stage();
           FXMLLoader loader = new FXMLLoader();
           Pane root = loader.load(Paths.get("src/main/java/View/Saple.fxml").toUri().toURL());
           Firstpage.setTitle("City Hol");
           Firstpage.setScene(new Scene(root,500,500));

           Firstpage.setResizable(false);
           Firstpage.show();

        }
        catch (Exception e){
            e.fillInStackTrace();
        }
    }
}
