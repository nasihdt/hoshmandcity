package com.example.hoshmandcity;

public enum Roles {
    ASSISTANTS,HERASAT,SHAHRDAR,BAZRAS,EMPLOYEE
}
