package Model;

public class Airport extends Department{
    public Airport(String namePlace,String phonenumber,String addressPlace,String namebos,String numberofemp){
        super(namePlace,phonenumber,addressPlace,namebos,numberofemp);

    }
}
