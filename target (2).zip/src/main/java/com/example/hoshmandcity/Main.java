package com.example.hoshmandcity;

import Model.*;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.nio.file.Paths;
import java.util.ArrayList;

public class Main extends Application {
    public static ArrayList<Shahrdar> listofshahrdar = new ArrayList<>();

//    static ArrayList<Assistants>  listsofassistants= new ArrayList<>();
//    static ArrayList<Herasat> listofHerasat = new ArrayList<>();
//    static ArrayList<Bazras> listofbazras = new ArrayList<>();
//    static ArrayList<Employee> listofemployee = new ArrayList<>();

    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) throws Exception{
        FirstPage();
    }

    public static void FirstPage(){
        try {
           Stage Firstpage = new Stage();
           FXMLLoader loader = new FXMLLoader();
           Pane root = loader.load(Paths.get("src/main/java/View/Saple.fxml").toUri().toURL());
           Firstpage.setTitle("City Hol");
           Firstpage.setScene(new Scene(root,500,500));

           Firstpage.setResizable(false);
           Firstpage.show();

        }
        catch (Exception e){
            e.fillInStackTrace();
        }
    }
}
