//package Controller;
//
//import Model.Shahrdar;
//import Model.ShahrdarDAO;
//import com.example.hoshmandcity.Main;
//import javafx.collections.FXCollections;
//import javafx.collections.ObservableList;
//import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
//import javafx.fxml.FXMLLoader;
//import javafx.scene.Scene;
//import javafx.scene.control.*;
//import javafx.scene.layout.Pane;
//import javafx.stage.Stage;
//
//import java.net.ConnectException;
//import java.net.URL;
//import java.net.URLConnection;
//import java.nio.file.Paths;
//import java.sql.SQLException;
//import java.util.Date;
//
//public class CreationshController{
//    @FXML
//    private TextField tx_name;
//    @FXML
//    private TextField tx_lastname;
//    @FXML
//    private TextField tx_number;
//    @FXML
//    private TextField date;
//    @FXML
//    private TextField tx_salary;
//    @FXML
//    private TextField tx_sabeghe;
//    @FXML
//    private Button record;
//    public static ObservableList<Shahrdar> shdata = FXCollections.observableArrayList();
//
//    @FXML
//    private TextField txpersonely;
//    @FXML
//    private TextField nameText;
//    @FXML
//    private TextField surnameText;
//    @FXML
//    private TextField txtPersonely;
//    @FXML
//    private TextField txtsalary;
//    @FXML
//    private TextField txtsabeghe;
//    @FXML
//    private TextField txtdate;
//    @FXML
//    private TextField txt_Lastname;
//    @FXML
//    private TextField txt_salary;
//    @FXML
//    private TextField txt_sabeghe;
//    @FXML
//    private TextField txtname;
//    @FXML
//    private TextArea resultArea;
//    @FXML
//    private TableView employeeTable;
//    @FXML
//    private TableColumn<Shahrdar,String> empNameColumn;
//    @FXML
//    private TableColumn<Shahrdar,String> empLastNameColumn;
//    @FXML
//    private TableColumn<Shahrdar, Date> empHireDateColumn;
//    @FXML
//    private TableColumn<Shahrdar,Integer> personelycolumn;
//    @FXML
//    private TableColumn<Shahrdar,Integer> salarycolumn;
//    @FXML
//    private TableColumn<Shahrdar,Integer> sabeghecolumn;
//    @FXML
//    private void searchsh(ActionEvent actionEvent) throws ClassNotFoundException, SQLException {
//        try {
//            //Get Employee information
//            Shahrdar sh = ShahrdarDAO.searchSharhdar(txpersonely.getText());
//            //Populate Employee on TableView and Display on TextArea
//            populateAndShowShahrdar(sh);
//        } catch (SQLException e) {
//            e.printStackTrace();
//            resultArea.setText("Error occurred while getting employee information from DB.\n" + e);
//            throw e;
//        }
//    }
//    @FXML
//    private void populateAndShowShahrdar(Shahrdar sh) throws ClassNotFoundException{
//        if (sh != null) {
//            populateShahrdar(sh);
//            setEmpInfoToTextArea(sh);
//        } else {
//            resultArea.setText("This employee does not exist!\n");
//        }
//    }
//    @FXML
//    private void searchShahrdar(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
//        try {
//            //Get all Employees information
//            ObservableList<Shahrdar> empData = ShahrdarDAO.searchshahrdar();
//           // Populate Employees on TableView
//            populateEmployees(empData);
//        } catch (SQLException e){
//            System.out.println("Error occurred while getting employees information from DB.\n" + e);
//            throw e;
//        }
//    }
//    @FXML
//    private void initialize (){
//         personelycolumn.setCellValueFactory(cellData -> cellData.getValue().personelynumberProperty().asObject());
//         empNameColumn.setCellValueFactory(cellData -> cellData.getValue().nameProperty());
//         empLastNameColumn.setCellValueFactory(cellData -> cellData.getValue().lastnameProperty());
//      //  empHireDateColumn.setCellValueFactory(cellData -> cellData.getValue().hireDateProperty().toString());
//        salarycolumn.setCellValueFactory(cellData -> cellData.getValue().salaryProperty().asObject());
//        sabeghecolumn.setCellValueFactory(cellData -> cellData.getValue().sabegheProperty().asObject());
//    }
//    @FXML
//    private void populateShahrdar (Shahrdar sh) throws ClassNotFoundException {
//        //Declare and ObservableList for table view
//        ObservableList<Shahrdar> shData = FXCollections.observableArrayList();
//        //Add employee to the ObservableList
//        shData.add(sh);
//        //Set items to the employeeTable
//        employeeTable.setItems(shData);
//    }
//    @FXML
//    private void setEmpInfoToTextArea ( Shahrdar sh) {
//        resultArea.setText("First Name: " + sh.getName() + "\n" +
//                "Last Name: " + sh.getLastname());
//    }
//    @FXML
//    private void populateEmployees (ObservableList<Shahrdar> shData) throws ClassNotFoundException {
//        //Set items to the employeeTable
//        employeeTable.setItems(shData);
//    }
//    @FXML
//    private void updateEmployeeEmail (ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
//        try {
//            ShahrdarDAO.updatesomeinformationShardar(txtname.getText(),txt_Lastname.getText(),txpersonely.getPrefColumnCount(),txt_salary.getText(),txt_sabeghe.getText());
//            resultArea.setText("The information has been update: " + txtname.getText() + "\n");
//        } catch (SQLException e) {
//            resultArea.setText("Problem occurred while updating email: " + e);
//        }
//    }
//    @FXML
//    private void insertEmployee (ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
//        try {
//            ShahrdarDAO.insertsh(nameText.getText(),surnameText.getText(),txtPersonely.getPrefColumnCount(),txtsalary.getAnchor(),txtsabeghe.getPrefColumnCount());
//            resultArea.setText("Employee inserted! \n");
//        } catch (SQLException e) {
//            resultArea.setText("Problem occurred while inserting employee " + e);
//            throw e;
//        }
//    }
//    @FXML
//    private void deleteEmployee (ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
//        try {
//            ShahrdarDAO.deleteshahrdarwithPersonelyNumber(txpersonely.getText());
//            resultArea.setText("Employee deleted! Employee id: " + txpersonely.getText() + "\n");
//        } catch (SQLException e) {
//            resultArea.setText("Problem occurred while deleting employee " + e);
//            throw e;
//        }
//    }
//    @FXML
//    public void Addshahrdar(ActionEvent event){
//           try{
////               Dialog<String> dialog = new Dialog<>();
////               String namesh = tx_name.getText().toString();
////               String lastnamesh = tx_lastname.getText().toString();
////               String personelysh = tx_number.getText().toString();
////               String datesh = date.getText().toString();
////               String salarysh = tx_salary.getText().toString();
////               String sabeghesh = tx_sabeghe.getText().toString();
//////               int m = salarysh*5;
//////               int s = m/100;
//////               salarysh = s+salarysh;
////
////                   Shahrdar shahrdar = new Shahrdar(namesh, lastnamesh, personelysh, datesh,salarysh, sabeghesh);
////                   shdata.add(shahrdar);
////
////                   System.out.println(shahrdar.toString());
////                   dialog.setTitle("Dialog box");
////                   ButtonType type = new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
////                   dialog.setContentText("Informations are recorded.");
////                   dialog.getDialogPane().getButtonTypes().add(type);
////                   dialog.showAndWait();
//
//
//           }
//           catch (Exception e){
//               e.fillInStackTrace();
//           }
//
//    }
//
//    @FXML
//    public void backclick(ActionEvent event){
//        try {
//
//            Stage stage =new Stage();
//            FXMLLoader loader = new FXMLLoader();
//            ((Stage)(((Button)event.getSource()).getScene().getWindow())).close();
//            Stage Firstpage = new Stage();
//            Pane root = loader.load(Paths.get("src/main/java/View/Menupage.fxml").toUri().toURL());
//            Firstpage.setTitle("Menu page");
//            Firstpage.setScene(new Scene(root,700,600));
//            Firstpage.setResizable(false);
//            Firstpage.show();
//        }
//        catch (Exception e){
//            e.fillInStackTrace();
//        }
//    }
//}
