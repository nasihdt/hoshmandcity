package Controller;

//import Model.DAOshahrdar;
import Model.Data;
import Model.Shahrdar;
import com.example.hoshmandcity.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import util.DBUtil;

import java.net.URL;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

public class EditshController {
      @FXML
      private TextField name;
      @FXML
      private TextField lastname;
      @FXML
      private TextField personely;
      @FXML
      private TextField salary;
      @FXML
      private DatePicker date;
      @FXML
      private TextField sabeghe;
//      public static Shahrdar shahrdar = new Shahrdar();
      public static ArrayList<Shahrdar> listsh = new ArrayList<>();

      @FXML
      private TextField nameEdit;
      @FXML
      private TextField lasEdit;
      @FXML
      private TextField salarEdit;
      @FXML
      private TextField sabeghEdit;


      @FXML
      private TextField prs;
      @FXML
      private TextArea txtResult;


      @FXML
      private TableColumn<Shahrdar,String> name_column;
      @FXML
      private TableColumn<Shahrdar,String> las_column;
      @FXML
      private TableColumn<Shahrdar,Integer> prs_column;
      @FXML
      private TableColumn<Shahrdar, Date> hire_column;
      @FXML
      private TableColumn<Shahrdar,Integer> salar_column;
      @FXML
      private TableColumn<Shahrdar,Integer> sabegh_column;
      @FXML
      private TableView table;


      @FXML
      private void updatShahrdarinfo(ActionEvent actionEvent) {
            try {
                  String editname = nameEdit.getText();
                  String editlast = lasEdit.getText();
                  String editsalar = salarEdit.getText();
                  String editsabegh = sabeghEdit.getText();

                  if(!Data.shahrdar.getName().equals(editname) || !Data.shahrdar.getLastname().equals(editlast) || !Data.shahrdar.getSalary().equals(editsalar) || !Data.shahrdar.getSabeghe().equals(editsabegh)){
                        Data.shahrdar.setName(editname);
                        Data.shahrdar.setLastname(editlast);
                        Data.shahrdar.setSalary(editsalar);
                        Data.shahrdar.setSabeghe(editsabegh);
                        txtResult.setText("information is updated.\n"+Data.shahrdar.getName()+"\n"+Data.shahrdar.getLastname()+"\n"+Data.shahrdar.getSalary()+"\n"+Data.shahrdar.getSabeghe());

                  }
            }
            catch (Exception e){

            }

      }

      @FXML
      private void insertShahrdar(ActionEvent actionEvent){
            Dialog<String> dialog = new Dialog<>();
            if(name.getText().isEmpty() || lastname.getText().isEmpty() ||personely.getText().isEmpty() || salary.getText().isEmpty()|| sabeghe.getText().isEmpty()){
                  dialog.setTitle("Dialog box");
                  ButtonType type = new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
                  dialog.setContentText("You should first write information.");
                  dialog.getDialogPane().getButtonTypes().add(type);
                  dialog.showAndWait();
            }
            else {
                  try {
                        int count = Integer.parseInt(sabeghe.getText()), sal = Integer.parseInt(salary.getText()), m, n;
                        while (count != 0) {
                              m = sal * 5;
                              n = m / 100;
                              sal = n + sal;
                              count--;
                        }
                        String sl = String.valueOf(sal);
                        Data.shahrdar = new Shahrdar(name.getText(), lastname.getText(), personely.getText(), date, sl.toString(), sabeghe.getText());

                        txtResult.setText("Employee inserted! \n" + name.getText() + "\n" + lastname.getText() + "\n" + personely.getText() + "\n" + date + "\n" + sl.toString() + "\n" + sabeghe.getText());
//                        name_column.setCellValueFactory(new PropertyValueFactory<>("name"));
//                        las_column.setCellValueFactory(new PropertyValueFactory<>("lastname"));
//                        prs_column.setCellValueFactory(new PropertyValueFactory<>("personelynumber"));
//                        hire_column.setCellValueFactory(new PropertyValueFactory<>("hire_date"));
//                        salar_column.setCellValueFactory(new PropertyValueFactory<>("salary"));
//                        sabegh_column.setCellValueFactory(new PropertyValueFactory<>("sabeghe"));
//
//                        ObservableList<Shahrdar> list = FXCollections.observableArrayList(Data.shahrdar);
//                        table.setItems(list);
//                        table.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
//                        table.getColumns().addAll(name_column, las_column, prs_column, hire_column, salar_column, sabegh_column);


                  } catch (Exception e) {
                        txtResult.setText("Problem occurred while inserting employee " + e);
                        throw e;
                  }
            }
      }

      @FXML
      private void deletesh(ActionEvent actionEvent){
             try {
                   String chooseprs = prs.getText();
                   if (chooseprs.equals(Data.shahrdar.getPersonelynumber())){
                         Data.shahrdar.setName(null);
                         Data.shahrdar.setLastname(null);
                         Data.shahrdar.setHire_date(null);
                         Data.shahrdar.setPersonelynumber(null);
                         Data.shahrdar.setSalary(null);
                         Data.shahrdar.setSabeghe(null);
                         txtResult.setText("Informations are deleted.");
                   }
             }
             catch (Exception e){
                   txtResult.setText("Problem occurred while inserting employee " + e);
                   throw e;
             }

      }
      @FXML
      private void gotomenupage(ActionEvent event) {
            try {

                  Stage stage =new Stage();
                  FXMLLoader loader = new FXMLLoader();
                  ((Stage)(((Button)event.getSource()).getScene().getWindow())).close();
                  Stage Firstpage = new Stage();
                  Pane root = loader.load(Paths.get("src/main/java/View/Menupage.fxml").toUri().toURL());
                  Firstpage.setTitle("Login page");
                  Firstpage.setScene(new Scene(root,700,600));
                  Firstpage.setResizable(false);
                  Firstpage.show();
            }
            catch (Exception e){
                  e.fillInStackTrace();
            }
      }
}