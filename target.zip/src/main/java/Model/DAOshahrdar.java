//package Model;
//
//import javafx.beans.property.IntegerProperty;
//import javafx.collections.FXCollections;
//import javafx.collections.ObservableList;
//import javafx.scene.control.DatePicker;
//import util.DBUtil;
//
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//public class DAOshahrdar {
//    public static  ObservableList<Shahrdar> shlist = FXCollections.observableArrayList();
//    public static Shahrdar searchShahrdar(String prsId) throws SQLException,ClassNotFoundException{
//        String selectStmt =  "SELECT * FROM employees WHERE Shahrdar_id="+prsId;
//        try {
//            ResultSet rssh = DBUtil.dbExecutequery(selectStmt);
//            Shahrdar shahrdar = getShahrdarfromResultSet(rssh);
//            return shahrdar;
//        }
//        catch (SQLException e){
//            System.out.println("While searching an employee with " + prsId + " id, an error occurred: " + e);
//            //Return exception
//            throw e;
//        }
//    }
//
//    private static Shahrdar getShahrdarfromResultSet(ResultSet rs) throws SQLException,ClassNotFoundException{
//       Shahrdar sh = null;
//       if(rs.next()){
//           sh = new Shahrdar();
//           sh.setName(rs.getString("Name"));
//           sh.setLastname(rs.getString("Lastname"));
//           sh.setPersonelynumber(rs.getInt("Personely"));
//           sh.setDatePicker(rs.getDate("HireDate"));
//           sh.setSalary(rs.getInt("Salary"));
//           sh.setSabeghe(rs.getInt("Sabeghe"));
//
//       }
//       return sh;
//    }
//
//    public static ObservableList<Shahrdar> searchShahrdars () throws SQLException,ClassNotFoundException {
//        String selectstmt = "SELECT * FROM Shahrdars";
//        try {
//            ResultSet rssh = DBUtil.dbExecutequery(selectstmt);
//            ObservableList<Shahrdar> ShahrdarList = getShahrdarlist(rssh);
//            return ShahrdarList;
//        }
//        catch (SQLException e){
//            System.out.println("SQL select operation has been failed: " + e);
//            //Return exception
//            throw e;
//        }
//
//    }
//
//    public static ObservableList<Shahrdar> getShahrdarlist (ResultSet rs) throws SQLException,ClassNotFoundException{
//          while (rs.next()){
//              Shahrdar sh = new Shahrdar();
//              sh.setName(rs.getString("Name"));
//              sh.setLastname(rs.getString("Lastname"));
//              sh.setPersonelynumber(rs.getInt("Personely"));
//              sh.setDatePicker(rs.getDate("HireDate"));
//              sh.setSalary(rs.getInt("Salary"));
//              sh.setSabeghe(rs.getInt("Sabeghe"));
//
//              shlist.add(sh);
//
//          }
//          return shlist;
//    }
//
//    public static void updateshinformation (String namesh, String lastnamesh, String salarysh,String sabeghesh,String personely) throws SQLException,ClassNotFoundException{
//        String updatestmt =
//                "BEGIN\n" +
//                        "   UPDATE Shahrdar\n" +
//                        "      SET NAME = '" + namesh + "'\n" +
//                        "      SET LASTNAME = '" + lastnamesh + "'\n" +
//                        "      SET SALARY = '" + salarysh + "'\n" +
//                        "      SET SABEGHE = '" + sabeghesh + "'\n" +
//                        "    WHERE EMPLOYEE_ID = " + personely + ";\n" +
//                        "   COMMIT;\n" +
//                        "END;";
////        try {
////             DBUtil.dbExecuteUpdate(updatestmt);
////        }
////        catch (SQLException e){
////            System.out.print("Error occurred while UPDATE Operation: " + e);
////            throw e;
////        }
//    }
//
//    public static void deleteshwithPRS(String prssh)throws SQLException,ClassNotFoundException{
//        String updatestmt =
//
//                "BEGIN\n" +
//                        "   DELETE FROM employees\n" +
//                        "         WHERE employee_id ="+ prssh +";\n" +
//                        "   COMMIT;\n" +
//                        "END;";
////        try {
////            DBUtil.dbExecuteUpdate(updatestmt);
////        }
////        catch (SQLException e){
////            System.out.print("Error occurred while DELETE Operation: " + e);
////            throw e;
////        }
//    }
//
//    public static void insertsh(String name, String lastname , String personely, DatePicker hire_date,int salary,String sabeghe) throws SQLException,ClassNotFoundException{
//        String updatestmt =
//                "BEGIN\n" +
//                        "INSERT INTO shahrdar\n" +
//                        "(EMPLOYEE_ID, FIRST_NAME, LAST_NAME, EMAIL, HIRE_DATE, JOB_ID)\n" +
//                        "VALUES\n" +
//                        "(sequence_employee.nextval, '"+name+"', '"+lastname+"','"+personely+"','"+hire_date+"''"+salary+"''"+sabeghe+"');\n" +
//                        "END;";
////        try {
////            DBUtil.dbExecuteUpdate(updatestmt);
////        }
////        catch (SQLException e){
////            System.out.print("Error occurred while DELETE Operation: " + e);
////            throw e;
////        }
//    }
//
//    public static ObservableList<Shahrdar> getShlist() {
//        return shlist;
//    }
//}
