package Model;

public class Data {
    public static Shahrdar shahrdar;
    public static Assistants assistants;
}
