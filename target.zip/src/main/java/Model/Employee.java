package Model;

import javafx.scene.control.TextField;

//public class Employee extends Person {
//    public Employee(String name, String lastname , String personelynumber, TextField datePicker, int salary , String sabeghe){
//        super(name,lastname,personelynumber,datePicker,salary,sabeghe);
//
//    }
//}
