package Model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.control.DatePicker;

import java.sql.Date;

public class Shahrdar extends Person {

       public Shahrdar(String name, String lastname, String personelynumber, DatePicker hire_date, String salary, String sabeghe){
           super(name,lastname,personelynumber,hire_date,salary,sabeghe);

       }


    public Shahrdar() {
        super();
    }


}
