//package Model;
//import javafx.beans.property.SimpleObjectProperty;
//import javafx.collections.FXCollections;
//import javafx.collections.ObservableList;
//import javafx.scene.control.DatePicker;
//import util.DBUtil;
////import .util.DBUtil;
//import java.sql.Date;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//public class ShahrdarDAO {
////    public static Shahrdar searchShahrdar(String shprs) throws SQLException,ClassNotFoundException{
////        String selectStmt = "SELECT * FROM employees WHERE Shahrdar_id="+shprs;
////        try {
////            ResultSet rsshahrdar = DBUtil.dbExecutequery(selectStmt);
////           // Shahrdar shahrdar = getShahrdarfromResultset(rsshahrdar);
////        }
////        catch (SQLException e){
////            System.out.println("While searching an Shahrdar with " + shprs + " id, an error occurred: " + e);
////            //Return exception
////            throw e;
////        }
////    }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//    public static Shahrdar searchSharhdar(String shprs) throws SQLException,ClassNotFoundException{
//        String selectStmt = "SELECT * FROM employees WHERE employee_id="+shprs;
//        try {
//             ResultSet rssh = DBUtil.dbExecutequery(selectStmt);
//             Shahrdar shahrdar = getShahrdarfromResultset(rssh);
//             return shahrdar;
//        }
//        catch (SQLException e){
//            System.out.println("While searching an Shahrdar with " + shprs + " id, an error occurred: " + e);
//            //Return exception
//            throw e;
//        }
//
//    }
//    private static Shahrdar getShahrdarfromResultset(ResultSet rs) throws SQLException,ClassNotFoundException{
//        Shahrdar sh = null;
//        if(rs.next()){
//            sh = new Shahrdar();
//            sh.setName(rs.getString("Name"));
//            sh.setLastname(rs.getString("Lastname"));
//            sh.setPersonelynumber(rs.getInt("Personelynumber"));
//            sh.setDatePicker(rs.getDate("Hire_Date"));
//            sh.setSalary(rs.getInt("Salary"));
//            sh.setSabeghe(rs.getInt("Sabeghe"));
//
//        }
//        return sh;
//    }
//    public static ObservableList<Shahrdar> searchshahrdar() throws SQLException,ClassNotFoundException{
//        String selectStmt = "SELECT * FROM Shahrdar";
//        try {
//             ResultSet rssh = DBUtil.dbExecutequery(selectStmt);
//             ObservableList<Shahrdar> shlist = (ObservableList<Shahrdar>) getShahrdarfromResultset(rssh);
//             return shlist;
//        }
//        catch (SQLException e){
//            System.out.println("SQL select operation has been failed: " + e);
//            //Return exception
//            throw e;
//        }
//    }
//    private static ObservableList<Shahrdar> getshahrdarlist(ResultSet rs) throws SQLException,ClassNotFoundException{
//        ObservableList<Shahrdar> shlist = FXCollections.observableArrayList();
//        while (rs.next()){
//            Shahrdar sh = new Shahrdar();
//            sh.setName(rs.getString("Name"));
//            sh.setLastname(rs.getString("Lastname"));
//            sh.setPersonelynumber(rs.getInt("Personelynumber"));
//            sh.setDatePicker(rs.getDate("Hire_Date"));
//            sh.setSalary(rs.getInt("Salary"));
//            sh.setSabeghe(rs.getInt("Sabeghe"));
//            shlist.add(sh);
//        }
//        return shlist;
//    }
//    public static void updatesomeinformationShardar(String name,String lastname,Integer personely,String salary,String sabeghe) throws SQLException,ClassNotFoundException{
//        String updateStatement = "BEGIN\n"+"  update shahrdar\n"+
//                "   set name ='" +name+"'\n"+
//                "   set lastname ='" +lastname+"'\n"+
//                "   set personely ='" +personely+"'\n"+
//                "   set salary ='" +salary+"'\n"+
//                "    set sabeghe = " +sabeghe+";\n"+
//                "   COMMIT;\n"+
//                "END;";
//        try {
//            DBUtil.dbExecuteUpdate(updateStatement);
//        }
//        catch (SQLException e){
//            System.out.print("Error occurred while UPDATE Operation: " + e);
//            throw e;
//        }
//    }
//    public static void deleteshahrdarwithPersonelyNumber(String personelysh) throws SQLException,ClassNotFoundException{
//        String updateStmt =
//                "BEGIN\n" +
//                        "   DELETE FROM shahrdar\n" +
//                        "         WHERE shahrdar ="+ personelysh +";\n" +
//                        "   COMMIT;\n" +
//                        "END;";
//
//        try {
//            DBUtil.dbExecuteUpdate(updateStmt);
//        } catch (SQLException e) {
//            System.out.print("Error occurred while DELETE Operation: " + e);
//            throw e;
//        }
//    }
//    public static void insertsh(String name , String lastname , Integer personely, Integer salary, Integer sabeghe) throws SQLException,ClassNotFoundException{
//        String updatestmt =
//                "BEGIN\n" +
//                        "INSERT INTO employees\n" +
//                        "(NAME, LAST_NAME,PERSONELY ,SALARY,SABEGHE)\n" +
//                        "VALUES\n" +
//                        "(sequence_SHAHRDAR.nextval, '"+name+"', '"+lastname+"','"+personely+"','"+salary+"','"+sabeghe+"');\n" +
//                        "END;";
//        try {
//            DBUtil.dbExecuteUpdate(updatestmt);
//        } catch (SQLException e) {
//            System.out.print("Error occurred while DELETE Operation: " + e);
//            throw e;
//        }
//
//    }
//}
